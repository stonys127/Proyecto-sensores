#include "mainwindow.h"
#include "registrarform.h"
#include "ui_registrarform.h"

#include <QMessageBox>

RegistrarForm::RegistrarForm(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::RegistrarForm)
{
    ui->setupUi(this);
}

RegistrarForm::~RegistrarForm()
{
    delete ui;
}

void RegistrarForm::on_registrarPushButton_clicked()
{
    Usuario usuario;
    usuario.setNombre(ui->nombreLineEdit->text());
    usuario.setContrasenya(ui->contrasenyaLineEdit->text());
    if (usuario.esValido())
    {
        if (m_controladorBD.insertaUsuario(usuario))
        {
            QMessageBox::information(this, "Mensaje", "Usuario registrado");
            MainWindow::globalInstance()->muestraPagina(MainWindow::PaginaInicio);
        }
        else
        {
            QMessageBox::warning(this, "Mensaje", "Usuario ya existe");
        }
    }
    else
    {
        QMessageBox::warning(this, "Mensaje", "Usuario inválido");
    }
}

void RegistrarForm::on_atrasPushButton_clicked()
{
    MainWindow::globalInstance()->muestraPagina(MainWindow::PaginaInicio);
}
