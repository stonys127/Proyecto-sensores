#ifndef SENSORPRECIPITACION_H
#define SENSORPRECIPITACION_H

#include "sensor.h"

class SensorPrecipitacion : public Sensor
{
    Q_OBJECT
public:
    explicit SensorPrecipitacion(QObject *parent = nullptr);
    virtual ~SensorPrecipitacion();
protected:
    void generaValorAleatorio() override;
};

#endif // SENSORPRECIPITACION_H
