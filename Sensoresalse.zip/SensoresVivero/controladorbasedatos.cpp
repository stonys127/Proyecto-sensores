#include "controladorbasedatos.h"

#include <QVariant>
#include <QSqlQuery>
#include <QDateTime>

ControladorBaseDatos::ControladorBaseDatos()
{
    // aquí nada
}

ControladorBaseDatos::~ControladorBaseDatos()
{
    // aquí nada
}

bool ControladorBaseDatos::insertaUsuario(const Usuario &usuario) const
{
    if (usuario.esValido())
    {
        QString sql = "insert into usuario(nombre, contrasenya) values(?, ?)";
        QSqlQuery query;
        query.prepare(sql);
        query.addBindValue(usuario.nombre());
        query.addBindValue(usuario.contrasenya());
        return query.exec();
    }
    return false;
}

bool ControladorBaseDatos::autenticaUsuario(const Usuario &usuario) const
{
    if (usuario.esValido())
    {
        QString sql = "select * from usuario where nombre like ? and contrasenya like ?";
        QSqlQuery query;
        query.prepare(sql);
        query.addBindValue(usuario.nombre());
        query.addBindValue(usuario.contrasenya());
        query.exec();
        return query.next();
    }
    return false;
}

bool ControladorBaseDatos::insertaDireccionViento(double valor) const
{
    QString sql = "insert into direccion_viento(valor, fecha_hora) values(?, ?)";
    QSqlQuery query;
    query.prepare(sql);
    query.addBindValue(valor);
    query.addBindValue(QDateTime::currentDateTime().toString("dd-MM-yyyy hh:mm:ss"));
    return query.exec();
}

bool ControladorBaseDatos::insertaHumedad(double valor) const
{
    QString sql = "insert into humedad(valor, fecha_hora) values(?, ?)";
    QSqlQuery query;
    query.prepare(sql);
    query.addBindValue(valor);
    query.addBindValue(QDateTime::currentDateTime().toString("dd-MM-yyyy hh:mm:ss"));
    return query.exec();
}

bool ControladorBaseDatos::insertaIntensidadLuz(double valor) const
{
    QString sql = "insert into intensidad_luz(valor, fecha_hora) values(?, ?)";
    QSqlQuery query;
    query.prepare(sql);
    query.addBindValue(valor);
    query.addBindValue(QDateTime::currentDateTime().toString("dd-MM-yyyy hh:mm:ss"));
    return query.exec();
}

bool ControladorBaseDatos::insertaPrecipitacion(double valor) const
{
    QString sql = "insert into precipitacion(valor, fecha_hora) values(?, ?)";
    QSqlQuery query;
    query.prepare(sql);
    query.addBindValue(valor);
    query.addBindValue(QDateTime::currentDateTime().toString("dd-MM-yyyy hh:mm:ss"));
    return query.exec();
}

bool ControladorBaseDatos::insertaTemperatura(double valor) const
{
    QString sql = "insert into temperatura(valor, fecha_hora) values(?, ?)";
    QSqlQuery query;
    query.prepare(sql);
    query.addBindValue(valor);
    query.addBindValue(QDateTime::currentDateTime().toString("dd-MM-yyyy hh:mm:ss"));
    return query.exec();
}

bool ControladorBaseDatos::insertaVelocidad(double valor) const
{
    QString sql = "insert into velocidad(valor, fecha_hora) values(?, ?)";
    QSqlQuery query;
    query.prepare(sql);
    query.addBindValue(valor);
    query.addBindValue(QDateTime::currentDateTime().toString("dd-MM-yyyy hh:mm:ss"));
    return query.exec();
}

double ControladorBaseDatos::ultimoHumedad() const
{
    QString sql = "select * from humedad order by id desc limit 1";
    QSqlQuery query;
    query.prepare(sql);
    query.exec();
    if (query.next())
    {
        return query.value("valor").toDouble();
    }
    else
    {
        return -1.0;
    }
}

double ControladorBaseDatos::ultimoVelocidad() const
{
    QString sql = "select * from velocidad order by id desc limit 1";
    QSqlQuery query;
    query.prepare(sql);
    query.exec();
    if (query.next())
    {
        return query.value("valor").toDouble();
    }
    else
    {
        return -1.0;
    }
}

double ControladorBaseDatos::ultimoTemperatura() const
{
    QString sql = "select * from temperatura order by id desc limit 1";
    QSqlQuery query;
    query.prepare(sql);
    query.exec();
    if (query.next())
    {
        return query.value("valor").toDouble();
    }
    else
    {
        return -1.0;
    }
}

double ControladorBaseDatos::ultimoIntensidadLuz() const
{
    QString sql = "select * from intensidad_luz order by id desc limit 1";
    QSqlQuery query;
    query.prepare(sql);
    query.exec();
    if (query.next())
    {
        return query.value("valor").toDouble();
    }
    else
    {
        return -1.0;
    }
}

double ControladorBaseDatos::ultimoPrecipitacion() const
{
    QString sql = "select * from precipitacion order by id desc limit 1";
    QSqlQuery query;
    query.prepare(sql);
    query.exec();
    if (query.next())
    {
        return query.value("valor").toDouble();
    }
    else
    {
        return -1.0;
    }
}

double ControladorBaseDatos::ultimoDireccionViento() const
{
    QString sql = "select * from direccion_viento order by id desc limit 1";
    QSqlQuery query;
    query.prepare(sql);
    query.exec();
    if (query.next())
    {
        return query.value("valor").toDouble();
    }
    else
    {
        return -1.0;
    }
}
