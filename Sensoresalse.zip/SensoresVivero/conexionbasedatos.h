#ifndef CONEXIONBASEDATOS_H
#define CONEXIONBASEDATOS_H

#include <QSqlDatabase>

class ConexionBaseDatos
{
public:
    explicit ConexionBaseDatos();
    virtual ~ConexionBaseDatos();
    void conecta();
    void configura();
private:
    QSqlDatabase m_db;
    static const QString s_nombreArchivoBD;
};

#endif // CONEXIONBASEDATOS_H
