#ifndef AUTENTICARFORM_H
#define AUTENTICARFORM_H

#include "controladorbasedatos.h"

#include <QWidget>

namespace Ui // Funcion para contener los nombres de usuario
{
class AutenticarForm;// se crea la clase
}

class AutenticarForm : public QWidget // a la  subclase que permite la herramienta de ventana en la interfas grafica
{
    Q_OBJECT
public:
    explicit AutenticarForm(QWidget *parent = nullptr);//puntero nulo, parent el puntero
    virtual ~AutenticarForm();
private slots:
    void on_atrasPushButton_clicked();
    void on_autenticarPushButton_clicked();
private:
    Ui::AutenticarForm *ui;
    ControladorBaseDatos m_controladorBD;
};

#endif // AUTENTICARFORM_H
