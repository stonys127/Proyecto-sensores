#include "mainwindow.h"
#include "inicioform.h"
#include "ui_inicioform.h"

InicioForm::InicioForm(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::InicioForm)
{
    ui->setupUi(this);
}

InicioForm::~InicioForm()
{
    delete ui;
}

void InicioForm::on_autenticarPushButton_clicked()
{
    MainWindow::globalInstance()->muestraPagina(MainWindow::PaginaAutenticar);
}

void InicioForm::on_registrarPushButton_clicked()
{
    MainWindow::globalInstance()->muestraPagina(MainWindow::PaginaRegistrar);
}
