#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

namespace Ui
{
class MainWindow;
}

class InicioForm;
class RegistrarForm;
class PrincipalForm;
class AutenticarForm;

class MainWindow : public QMainWindow
{
    Q_OBJECT
public:
    enum Pagina
    {
        PaginaInicio,
        PaginaRegistrar,
        PaginaAutenticar,
        PaginaPrincipal
    };

    explicit MainWindow(QWidget *parent = nullptr);
    virtual ~MainWindow();
    void muestraPagina(int pagina) const;
    static const MainWindow *globalInstance();
private:
    void creaObjectos();
    void configuraPaginas();

    Ui::MainWindow *ui;
    InicioForm *m_inicioForm;
    RegistrarForm *m_registrarForm;
    PrincipalForm *m_principalForm;
    AutenticarForm *m_autenticarForm;
    static const MainWindow *s_instance;
};

#endif // MAINWINDOW_H
