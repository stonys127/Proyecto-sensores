#ifndef SENSORDIRECCIONVIENTO_H
#define SENSORDIRECCIONVIENTO_H

#include "sensor.h"

class SensorDireccionViento : public Sensor
{
    Q_OBJECT
public:
    explicit SensorDireccionViento(QObject *parent = nullptr);
    virtual ~SensorDireccionViento();
protected:
    void generaValorAleatorio() override;
};

#endif // SENSORDIRECCIONVIENTO_H
