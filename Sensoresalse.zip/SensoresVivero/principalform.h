#ifndef PRINCIPALFORM_H
#define PRINCIPALFORM_H

#include "controladorbasedatos.h"

#include <QWidget>

namespace Ui
{
class PrincipalForm;
}

class QTimer;

class SensorHumedad;
class SensorVelocidad;
class SensorTemperatura;
class SensorIntensidadLuz;
class SensorPrecipitacion;
class SensorDireccionViento;

class PrincipalForm : public QWidget
{
    Q_OBJECT
public:
    explicit PrincipalForm(QWidget *parent = nullptr);
    virtual ~PrincipalForm();
private slots:
    void yaPasoUnMinuto();
    void on_humedadPushButton_clicked();
    void on_velocidadPushButton_clicked();
    void on_temperaturaPushButton_clicked();
    void on_intensidadLuzPushButton_clicked();
    void on_precipitacionPushButton_clicked();
    void on_direccionVientoPushButton_clicked();
    void on_ultimosDatosGuardadosPushButton_clicked();
private:
    void creaObjetos();
    void muestraLedRojo();
    void muestraLedVerde();
    void muestraLedAmarillo();
    void muestraLedApagado();

    Ui::PrincipalForm *ui;
    QTimer *m_temporizador;
    SensorHumedad *m_sensorHumedad;
    SensorVelocidad *m_sensorVelocidad;
    SensorTemperatura *m_sensorTemperatura;
    SensorIntensidadLuz *m_sensorIntensidadLuz;
    SensorPrecipitacion *m_sensorPrecipitacion;
    SensorDireccionViento *m_sensorDireccionViento;
    ControladorBaseDatos m_controladorBD;
};

#endif // PRINCIPALFORM_H
