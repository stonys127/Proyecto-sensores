#include "sensorhumedad.h"

#include <QRandomGenerator>

SensorHumedad::SensorHumedad(QObject *parent)
    : Sensor(parent)
{
    // aquí nada
}

SensorHumedad::~SensorHumedad()
{
    // aquí nada
}

void SensorHumedad::generaValorAleatorio()
{
    // 0% - 100%
    const int entero = QRandomGenerator::global()->bounded(0, 99 + 1);
    const int decimal = QRandomGenerator::global()->bounded(0, 999 + 1);
    m_valor = entero + decimal / 1000.0;
}
