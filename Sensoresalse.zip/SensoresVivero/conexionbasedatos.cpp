#include "conexionbasedatos.h"

#include <QSqlQuery>

const QString ConexionBaseDatos::s_nombreArchivoBD = "sensorviveroBD.sqlite";

ConexionBaseDatos::ConexionBaseDatos()
{
    m_db = QSqlDatabase::addDatabase("QSQLITE");
}

ConexionBaseDatos::~ConexionBaseDatos()
{
    m_db.close();
}

void ConexionBaseDatos::conecta()
{
    m_db.setDatabaseName(s_nombreArchivoBD);
    m_db.open();
}

void ConexionBaseDatos::configura()
{
    QString sql = "create table if not exists usuario(id integer primary key autoincrement, nombre varchar(255) unique not null, contrasenya text not null)";
    QSqlQuery query;
    query.prepare(sql);
    query.exec();

    sql = "create table if not exists direccion_viento(id integer primary key autoincrement, valor double not null, fecha_hora varchar(255) not null)";
    query.prepare(sql);
    query.exec();

    sql = "create table if not exists humedad(id integer primary key autoincrement, valor double not null, fecha_hora varchar(255) not null)";
    query.prepare(sql);
    query.exec();

    sql = "create table if not exists intensidad_luz(id integer primary key autoincrement, valor double not null, fecha_hora varchar(255) not null)";
    query.prepare(sql);
    query.exec();

    sql = "create table if not exists precipitacion(id integer primary key autoincrement, valor double not null, fecha_hora varchar(255) not null)";
    query.prepare(sql);
    query.exec();

    sql = "create table if not exists temperatura(id integer primary key autoincrement, valor double not null, fecha_hora varchar(255) not null)";
    query.prepare(sql);
    query.exec();

    sql = "create table if not exists velocidad(id integer primary key autoincrement, valor double not null, fecha_hora varchar(255) not null)";
    query.prepare(sql);
    query.exec();
}
