#ifndef SENSOR_H
#define SENSOR_H

#include <QObject>

class Sensor : public QObject
{
    Q_OBJECT
public:
    explicit Sensor(QObject *parent = nullptr);
    virtual ~Sensor();
    void leeValor();
    double valor() const;
protected:
    virtual void generaValorAleatorio() = 0;

    double m_valor;
};

#endif // SENSOR_H
