#ifndef SENSORHUMEDAD_H
#define SENSORHUMEDAD_H

#include "sensor.h"

class SensorHumedad : public Sensor
{
    Q_OBJECT
public:
    explicit SensorHumedad(QObject *parent = nullptr);
    virtual ~SensorHumedad();
protected:
    void generaValorAleatorio() override;
};

#endif // SENSORHUMEDAD_H
