#ifndef INICIOFORM_H
#define INICIOFORM_H

#include <QWidget>

namespace Ui
{
class InicioForm;
}

class InicioForm : public QWidget
{
    Q_OBJECT
public:
    explicit InicioForm(QWidget *parent = nullptr);
    virtual ~InicioForm();
private slots:
    void on_registrarPushButton_clicked();
    void on_autenticarPushButton_clicked();
private:
    Ui::InicioForm *ui;
};

#endif // INICIOFORM_H
