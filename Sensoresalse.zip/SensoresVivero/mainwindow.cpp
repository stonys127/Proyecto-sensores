#include "inicioform.h"
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "registrarform.h"
#include "principalform.h"
#include "autenticarform.h"

const MainWindow *MainWindow::s_instance = nullptr;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    creaObjectos();
    configuraPaginas();
    muestraPagina(PaginaInicio);
}

MainWindow::~MainWindow()
{
    delete ui;
}

const MainWindow *MainWindow::globalInstance()
{
    return s_instance;
}

void MainWindow::creaObjectos()
{
    s_instance = this;
    m_inicioForm = new InicioForm(this);
    m_registrarForm = new RegistrarForm(this);
    m_autenticarForm = new AutenticarForm(this);
    m_principalForm = new PrincipalForm(this);
}

void MainWindow::configuraPaginas()
{
    ui->stackedWidget->addWidget(m_inicioForm);
    ui->stackedWidget->addWidget(m_registrarForm);
    ui->stackedWidget->addWidget(m_autenticarForm);
    ui->stackedWidget->addWidget(m_principalForm);
}

void MainWindow::muestraPagina(int pagina) const
{
    ui->stackedWidget->setCurrentIndex(pagina);
}
