#include "sensorintensidadluz.h"

#include <QRandomGenerator>

SensorIntensidadLuz::SensorIntensidadLuz(QObject *parent)
    : Sensor(parent)
{
    // aquí nada
}

SensorIntensidadLuz::~SensorIntensidadLuz()
{
    // aquí nada
}

void SensorIntensidadLuz::generaValorAleatorio()
{
    // 0, 2000 lumen
    const int entero = QRandomGenerator::global()->bounded(0, 1999 + 1);
    const int decimal = QRandomGenerator::global()->bounded(0, 999 + 1);
    m_valor = entero + decimal / 1000.0;
}
