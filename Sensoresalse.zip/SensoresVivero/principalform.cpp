#include "principalform.h"
#include "sensorhumedad.h"
#include "sensorvelocidad.h"
#include "ui_principalform.h"
#include "sensortemperatura.h"
#include "sensorintensidadluz.h"
#include "sensorprecipitacion.h"
#include "sensordireccionviento.h"

#include <QTimer>

#define UN_MINUTO 60000
#define CIEN_MILISEGUNDOS 100

PrincipalForm::PrincipalForm(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::PrincipalForm)
{
    ui->setupUi(this);
    creaObjetos();
    connect(m_temporizador, &QTimer::timeout, this, &PrincipalForm::yaPasoUnMinuto);
    m_temporizador->start(UN_MINUTO);
}

PrincipalForm::~PrincipalForm()
{
    delete ui;
}

void PrincipalForm::muestraLedRojo()
{
    ui->ledLabel->setPixmap(QPixmap(":/img/rojo.png").scaled(49, 49));
}

void PrincipalForm::muestraLedVerde()
{
    ui->ledLabel->setPixmap(QPixmap(":/img/verde.png").scaled(49, 49));
}

void PrincipalForm::muestraLedAmarillo()
{
    ui->ledLabel->setPixmap(QPixmap(":/img/amarillo.png").scaled(49, 49));
}

void PrincipalForm::muestraLedApagado()
{
    ui->ledLabel->setPixmap(QPixmap());
}

void PrincipalForm::yaPasoUnMinuto()
{
    double valor = 0.0;

    m_sensorHumedad->leeValor();
    valor = m_sensorHumedad->valor();
    m_controladorBD.insertaHumedad(valor);

    m_sensorVelocidad->leeValor();
    valor = m_sensorVelocidad->valor();
    m_controladorBD.insertaVelocidad(valor);

    m_sensorTemperatura->leeValor();
    valor = m_sensorTemperatura->valor();
    m_controladorBD.insertaTemperatura(valor);

    m_sensorIntensidadLuz->leeValor();
    valor = m_sensorIntensidadLuz->valor();
    m_controladorBD.insertaIntensidadLuz(valor);

    m_sensorPrecipitacion->leeValor();
    valor = m_sensorPrecipitacion->valor();
    m_controladorBD.insertaPrecipitacion(valor);

    m_sensorDireccionViento->leeValor();
    valor = m_sensorDireccionViento->valor();
    m_controladorBD.insertaDireccionViento(valor);
}

void PrincipalForm::on_ultimosDatosGuardadosPushButton_clicked()
{
    ui->humedadLineEdit->setText(QString::number(m_controladorBD.ultimoHumedad()));
    ui->velocidadLineEdit->setText(QString::number(m_controladorBD.ultimoVelocidad()));
    ui->temperaturaLineEdit->setText(QString::number(m_controladorBD.ultimoTemperatura()));
    ui->intensidadLuzLineEdit->setText(QString::number(m_controladorBD.ultimoIntensidadLuz()));
    ui->precipitacionLineEdit->setText(QString::number(m_controladorBD.ultimoPrecipitacion()));
    ui->direccionVientoLineEdit->setText(QString::number(m_controladorBD.ultimoDireccionViento()));
}

void PrincipalForm::creaObjetos()
{
    m_temporizador = new QTimer(this);
    m_sensorHumedad = new SensorHumedad(this);
    m_sensorVelocidad = new SensorVelocidad(this);
    m_sensorTemperatura = new SensorTemperatura(this);
    m_sensorIntensidadLuz = new SensorIntensidadLuz(this);
    m_sensorPrecipitacion = new SensorPrecipitacion(this);
    m_sensorDireccionViento = new SensorDireccionViento(this);
}

void PrincipalForm::on_temperaturaPushButton_clicked()
{
    const double valor = m_sensorTemperatura->valor();

    // verde: -10ºC, 22.5ºC
    if (valor >= -10.0 && valor < 22.5)
    {
        muestraLedVerde();
    }
    // amarillo: 22.5ºC, 33.5ºC
    if (valor >= 22.5 && valor < 33.5)
    {
        muestraLedAmarillo();
    }
    // rojo: 33.5ºC, 45ºC
    if (valor >= 33.5 && valor <= 45.0)
    {
        muestraLedRojo();
    }
}

void PrincipalForm::on_humedadPushButton_clicked()
{
    const double valor = m_sensorHumedad->valor();

    // verde: 0, 33.3
    if (valor >= 0.0 && valor < 33.3)
    {
        muestraLedVerde();
    }
    // amarillo: 33.3, 66.6
    if (valor >= 33.3 && valor < 66.6)
    {
        muestraLedAmarillo();
    }
    // rojo: 66.6, 100
    if (valor >= 66.6 && valor <= 100.0)
    {
        muestraLedRojo();
    }
}

void PrincipalForm::on_direccionVientoPushButton_clicked()
{
    const double valor = m_sensorDireccionViento->valor();

    // verde: -180, -60
    if (valor >= -180.0 && valor < -60.0)
    {
        muestraLedVerde();
    }
    // amarillo: -60, 60
    if (valor >= -60.0 && valor < 60.0)
    {
        muestraLedAmarillo();
    }
    // rojo: 60, 180
    if (valor >= 60.0 && valor <= 180.0)
    {
        muestraLedRojo();
    }
}

void PrincipalForm::on_intensidadLuzPushButton_clicked()
{
    const double valor = m_sensorIntensidadLuz->valor();

    // verde: 0, 666.6
    if (valor >= 0.0 && valor < 666.6)
    {
        muestraLedVerde();
    }
    // amarillo: 666.6, 1333.2
    if (valor >= 666.6 && valor < 1333.2)
    {
        muestraLedAmarillo();
    }
    // rojo: 1333.2, 2000
    if (valor >= 1333.2 && valor <= 2000.0)
    {
        muestraLedRojo();
    }
}

void PrincipalForm::on_precipitacionPushButton_clicked()
{
    const double valor = m_sensorPrecipitacion->valor();

    // verde: 0, 16.6
    if (valor >= 0.0 && valor < 16.6)
    {
        muestraLedVerde();
    }
    // amarillo: 16.6, 33.2
    if (valor >= 16.6 && valor < 33.2)
    {
        muestraLedAmarillo();
    }
    // rojo: 33.2, 50
    if (valor >= 33.2 && valor <= 50.0)
    {
        muestraLedRojo();
    }
}

void PrincipalForm::on_velocidadPushButton_clicked()
{
    const double valor = m_sensorVelocidad->valor();

    // verde: 0, 13.3
    if (valor >= 0.0 && valor < 13.3)
    {
        muestraLedVerde();
    }
    // amarillo: 13.3, 26.6
    if (valor >= 13.3 && valor < 26.6)
    {
        muestraLedAmarillo();
    }
    // rojo: 26.6, 40
    if (valor >= 26.6 && valor <= 40.0)
    {
        muestraLedRojo();
    }
}
