#ifndef SENSORVELOCIDAD_H
#define SENSORVELOCIDAD_H

#include "sensor.h"

class SensorVelocidad : public Sensor
{
    Q_OBJECT
public:
    explicit SensorVelocidad(QObject *parent = nullptr);
    virtual ~SensorVelocidad();
protected:
    void generaValorAleatorio() override;
};

#endif // SENSORVELOCIDAD_H
