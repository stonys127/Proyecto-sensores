#include "sensorvelocidad.h"

#include <QRandomGenerator>

SensorVelocidad::SensorVelocidad(QObject *parent)
    : Sensor(parent)
{
    // aquí nada
}

SensorVelocidad::~SensorVelocidad()
{
    // aquí nada
}

void SensorVelocidad::generaValorAleatorio()
{
    // 0m/s, 40m/s
    const int entero = QRandomGenerator::global()->bounded(0, 39 + 1);
    const int decimal = QRandomGenerator::global()->bounded(0, 999 + 1);
    m_valor = entero + decimal / 1000.0;
}
