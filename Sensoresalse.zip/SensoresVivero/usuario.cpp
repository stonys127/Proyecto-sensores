#include "usuario.h"

Usuario::Usuario()
{
    m_nombre = "";
    m_contrasenya = "";
}

Usuario::~Usuario()
{
    // aquí nada
}

void Usuario::setNombre(const QString &nombre)
{
    m_nombre = nombre;
}

void Usuario::setContrasenya(const QString &contrasenya)
{
    m_contrasenya = contrasenya;
}

QString Usuario::nombre() const
{
    return m_nombre;
}

QString Usuario::contrasenya() const
{
    return m_contrasenya;
}

bool Usuario::esValido() const
{
    return !m_nombre.isEmpty() && !m_contrasenya.isEmpty();
}
