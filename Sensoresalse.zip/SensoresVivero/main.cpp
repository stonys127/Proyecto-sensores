#include "mainwindow.h"
#include "conexionbasedatos.h"

#include <QApplication>

int main(int argc, char **argv)
{
    QApplication app(argc, argv);
    app.setStyle("fusion");

    ConexionBaseDatos conexionBD;
    conexionBD.conecta();
    conexionBD.configura();

    MainWindow w;
    w.show();

    return app.exec();
}
