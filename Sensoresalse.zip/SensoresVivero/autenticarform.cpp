#include "mainwindow.h"
#include "autenticarform.h"
#include "ui_autenticarform.h"

#include <QMessageBox>

AutenticarForm::AutenticarForm(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::AutenticarForm)
{
    ui->setupUi(this);
}

AutenticarForm::~AutenticarForm()
{
    delete ui;
}

void AutenticarForm::on_autenticarPushButton_clicked()
{
    Usuario usuario;
    usuario.setNombre(ui->nombreLineEdit->text());
    usuario.setContrasenya(ui->contrasenyaLineEdit->text());
    if (usuario.esValido())
    {
        if (m_controladorBD.autenticaUsuario(usuario))
        {
            QMessageBox::information(this, "Mensaje", "Bienvenido");
            MainWindow::globalInstance()->muestraPagina(MainWindow::PaginaPrincipal);
        }
        else
        {
            QMessageBox::warning(this, "Mensaje", "Usuario no existe");
        }
    }
    else
    {
        QMessageBox::warning(this, "Mensaje", "Usuario inválido");
    }
}

void AutenticarForm::on_atrasPushButton_clicked()
{
    MainWindow::globalInstance()->muestraPagina(MainWindow::PaginaInicio);
}
