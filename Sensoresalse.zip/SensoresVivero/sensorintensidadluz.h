#ifndef SENSORINTENSIDADLUZ_H
#define SENSORINTENSIDADLUZ_H

#include "sensor.h"

class SensorIntensidadLuz : public Sensor
{
    Q_OBJECT
public:
    explicit SensorIntensidadLuz(QObject *parent = nullptr);
    virtual ~SensorIntensidadLuz();
protected:
    void generaValorAleatorio() override;
};

#endif // SENSORINTENSIDADLUZ_H
