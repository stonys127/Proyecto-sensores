#include "sensordireccionviento.h"

#include <QRandomGenerator>

SensorDireccionViento::SensorDireccionViento(QObject *parent)
    : Sensor(parent)
{
    // aquí nada
}

SensorDireccionViento::~SensorDireccionViento()
{
    // aquí nada
}

void SensorDireccionViento::generaValorAleatorio()
{
    // -180º, +180º
    const int entero = QRandomGenerator::global()->bounded(0, 179 + 1);
    const int decimal = QRandomGenerator::global()->bounded(0, 999 + 1);
    const int signo = QRandomGenerator::global()->bounded(1, 2 + 1) == 1 ? +1 : -1;
    m_valor = entero + decimal / 1000.0;
    m_valor *= signo;
}
