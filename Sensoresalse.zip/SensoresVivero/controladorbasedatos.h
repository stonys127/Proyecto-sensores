#ifndef CONTROLADORBASEDATOS_H
#define CONTROLADORBASEDATOS_H

#include "usuario.h"

class ControladorBaseDatos
{
public:
    explicit ControladorBaseDatos();
    virtual ~ControladorBaseDatos();
    double ultimoHumedad() const;
    double ultimoVelocidad() const;
    double ultimoTemperatura() const;
    double ultimoIntensidadLuz() const;
    double ultimoPrecipitacion() const;
    double ultimoDireccionViento() const;
    bool insertaHumedad(double valor) const;
    bool insertaVelocidad(double valor) const;
    bool insertaTemperatura(double valor) const;
    bool insertaPrecipitacion(double valor) const;
    bool insertaIntensidadLuz(double valor) const;
    bool insertaDireccionViento(double valor) const;
    bool insertaUsuario(const Usuario &usuario) const;
    bool autenticaUsuario(const Usuario &usuario) const;
};

#endif // CONTROLADORBASEDATOS_H
