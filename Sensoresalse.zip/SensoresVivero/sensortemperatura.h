#ifndef SENSORTEMPERATURA_H
#define SENSORTEMPERATURA_H

#include "sensor.h"

class SensorTemperatura : public Sensor
{
    Q_OBJECT
public:
    explicit SensorTemperatura(QObject *parent = nullptr);
    virtual ~SensorTemperatura();
protected:
    void generaValorAleatorio() override;
};

#endif // SENSORTEMPERATURA_H
