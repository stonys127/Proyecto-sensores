#include "sensor.h"

Sensor::Sensor(QObject *parent)
    : QObject(parent)
{
    m_valor = 0.0;
}

Sensor::~Sensor()
{
    // aquí nada
}

void Sensor::leeValor()
{
    generaValorAleatorio();
}

double Sensor::valor() const
{
    return m_valor;
}
