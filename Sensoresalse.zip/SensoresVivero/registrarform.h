#ifndef REGISTRARFORM_H
#define REGISTRARFORM_H

#include "controladorbasedatos.h"

#include <QWidget>

namespace Ui
{
class RegistrarForm;
}

class RegistrarForm : public QWidget
{
    Q_OBJECT
public:
    explicit RegistrarForm(QWidget *parent = nullptr);
    virtual ~RegistrarForm();
private slots:
    void on_atrasPushButton_clicked();
    void on_registrarPushButton_clicked();
private:
    Ui::RegistrarForm *ui;
    ControladorBaseDatos m_controladorBD;
};

#endif // REGISTRARFORM_H
