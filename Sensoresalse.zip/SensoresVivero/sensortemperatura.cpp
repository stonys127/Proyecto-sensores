#include "sensortemperatura.h"

#include <QRandomGenerator>

SensorTemperatura::SensorTemperatura(QObject *parent)
    : Sensor(parent)
{
    // aquí nada
}

SensorTemperatura::~SensorTemperatura()
{
    // aquí nada
}

void SensorTemperatura::generaValorAleatorio()
{
    // -10ºC, 45ºC

    // -10, ..., -1
    const int entero1 = QRandomGenerator::global()->bounded(1, 10 + 1);
    const int decimal1 = QRandomGenerator::global()->bounded(0, 999 + 1);
    const double valor1 = (entero1 + decimal1 / 1000.0) * (-1);

    // 0, 45
    const int entero2 = QRandomGenerator::global()->bounded(0, 44 + 1);
    const int decimal2 = QRandomGenerator::global()->bounded(0, 999 + 1);
    const double valor2 = entero2 + decimal2 / 1000.0;

    m_valor = QRandomGenerator::global()->bounded(1, 2 + 1) == 1 ? valor1 : valor2;
}
