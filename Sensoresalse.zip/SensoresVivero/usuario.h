#ifndef USUARIO_H
#define USUARIO_H

#include <QString>

class Usuario
{
public:
    explicit Usuario();
    virtual ~Usuario();
    void setNombre(const QString &nombre);
    void setContrasenya(const QString &contrasenya);
    QString nombre() const;
    QString contrasenya() const;
    bool esValido() const;
private:
    QString m_nombre;
    QString m_contrasenya;
};

#endif // USUARIO_H
